---
layout: page
title: About myself
excerpt: "Everyone has a story"
modified: 2014-08-08T19:44:38.564948-04:00
---

I'm Alex Golubev a software engineer. Doing distributed computing, functional programming and other IT stuff for fun (and professionally)

Everything I'm writing here will try to post to GitHub.

Don't hesitate to drop your message in discussion or any other way.